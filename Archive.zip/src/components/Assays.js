import React, { Component } from 'react';

class Assays extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return(            
            <div id="page-wrap" className="container-fluid">
                <div className="container-fluid">
                    <div className="row text-center">
                        <img id="logo" src="/assets/images/GOSH.png" height="40px" width="200px"/>                    
                        <div className="col-sm-4 ml-auto">
                          
                        </div>                 
                        <div className="ml-auto">
                            
                        </div>   
                    </div>                
                </div>
                <div className="table-container container-fluid">                    
                </div>
            </div>
        );
    }
}

export default Assays;